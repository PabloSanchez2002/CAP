Grupo: 1461
Pareja: 3
Participantes:
-Pablo Sanchez Fernadez del Pozo
-Carlos Riveira Ramos
